// @ts-ignore
var now = new Date().getTime();
// @ts-ignore
var offer_start_time = new Date(now + 5 * 1000);
// @ts-ignore
var offer_end_time = new Date(now + 100 * 1000);

var HISTORY_URL = 'https://screeps.com/room-history/';

var API_URL = 'https://screeps.com/api/';
var WEBSOCKET_URL = 'https://screeps.com/socket/';

var PROMO_PIXELS_START = new Date(now).getTime();
// @ts-ignore
var CONFIG = {
    API_URL: API_URL,
    HISTORY_URL: HISTORY_URL,
    WEBSOCKET_URL: WEBSOCKET_URL,
    PREFIX: '',
    IS_PTR: false,
    DEBUG: false,
    XSOLLA_SANDBOX: false,
    OFFER_START_TIME: Date.UTC(offer_start_time.getUTCFullYear(), offer_start_time.getUTCMonth(), offer_start_time.getUTCDate(), offer_start_time.getUTCHours(), offer_start_time.getUTCMinutes(), offer_start_time.getUTCSeconds()),
    OFFER_END_TIME: Date.UTC(offer_end_time.getUTCFullYear(), offer_end_time.getUTCMonth(), offer_end_time.getUTCDate(), offer_end_time.getUTCHours(), offer_end_time.getUTCMinutes(), offer_end_time.getUTCSeconds()),
    NOT_LOSE_POWER_LEVEL_END_TIME: Date.UTC(2019, 5, 17, 23, 59, 59),
    OFFER_POWER_LEVEL_PROMO_END_TIME: offer_end_time,
    PROMO_PIXELS_START: new Date(now).getTime(),
    PROMO_PIXELS_END: new Date(PROMO_PIXELS_START + 30 * 24 * 60 * 60 * 1000).getTime(),
    SEASON_START_TIME: new Date(Date.UTC(2024, 1, 1, 18, 0, 0)) .getTime(),
    SEASON_WORLD_LANDING: new Date(Date.UTC(2024, 0, 25, 18, 0, 0)).getTime()
};
// nw = {} as NW; // Uncomment this line if you need test nw in browser and comment next line
